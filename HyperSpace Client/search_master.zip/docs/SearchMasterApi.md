# search_master.SearchMasterApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_batch**](SearchMasterApi.md#add_batch) | **PUT** /api/v1/{collectionName}/batch | Add a new batch to the collection
[**add_vector**](SearchMasterApi.md#add_vector) | **PUT** /api/v1/{collectionName}/vector/add | Add a new vector to the collection
[**change_log_level**](SearchMasterApi.md#change_log_level) | **POST** /api/v1/configuration/changeLogLevel/{logLevel} | Set logger level
[**clear_collection**](SearchMasterApi.md#clear_collection) | **GET** /api/v1/{collectionName}/delete | Clear all collection vectors
[**cluster_status**](SearchMasterApi.md#cluster_status) | **GET** /api/v1/clusterStatus | Get the status of all data-nodes
[**commit**](SearchMasterApi.md#commit) | **GET** /api/v1/{collectionName}/commit | Commit
[**create_collection**](SearchMasterApi.md#create_collection) | **PUT** /api/v1/collection/{collectionName} | Create a new collection
[**delete_collection**](SearchMasterApi.md#delete_collection) | **GET** /api/v1/collection/{collectionName} | Delete a collection
[**delete_function**](SearchMasterApi.md#delete_function) | **GET** /api/v1/{collectionName}/function/delete/{functionName} | Delete function by name
[**delete_vector**](SearchMasterApi.md#delete_vector) | **GET** /api/v1/{collectionName}/vector/delete | Delete vector by Id 
[**find_vector_by_id**](SearchMasterApi.md#find_vector_by_id) | **GET** /api/v1/{collectionName}/vector/get | Find vector by Id
[**get_function**](SearchMasterApi.md#get_function) | **GET** /api/v1/{collectionName}/function/{functionName} | Get Function
[**get_schema**](SearchMasterApi.md#get_schema) | **GET** /api/v1/{collectionName}/schema | Get schema of collection
[**login**](SearchMasterApi.md#login) | **POST** /api/v1/login | Login
[**search_data**](SearchMasterApi.md#search_data) | **POST** /api/v1/{collectionName}/search/{functionName} | Find top X similar vectors in the dataset according to the selected search option.
[**set_function**](SearchMasterApi.md#set_function) | **PUT** /api/v1/{collectionName}/function/{functionName} | Set Function
[**update_vector**](SearchMasterApi.md#update_vector) | **POST** /api/v1/{collectionName}/vector/update | Update vector by Id in the dataset

# **add_batch**
> str add_batch(body, collection_name)

Add a new batch to the collection

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
body = [search_master.VectorDto()] # list[VectorDto] | 
collection_name = 'collection_name_example' # str | 

try:
    # Add a new batch to the collection
    api_response = api_instance.add_batch(body, collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->add_batch: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**list[VectorDto]**](VectorDto.md)|  | 
 **collection_name** | **str**|  | 

### Return type

**str**

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **add_vector**
> StatusDto add_vector(body, collection_name)

Add a new vector to the collection

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
body = search_master.VectorDto() # VectorDto | 
collection_name = 'collection_name_example' # str | 

try:
    # Add a new vector to the collection
    api_response = api_instance.add_vector(body, collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->add_vector: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**VectorDto**](VectorDto.md)|  | 
 **collection_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **change_log_level**
> str change_log_level(log_level)

Set logger level

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
log_level = 'log_level_example' # str | 

try:
    # Set logger level
    api_response = api_instance.change_log_level(log_level)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->change_log_level: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **log_level** | **str**|  | 

### Return type

**str**

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **clear_collection**
> StatusDto clear_collection(collection_name)

Clear all collection vectors

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 

try:
    # Clear all collection vectors
    api_response = api_instance.clear_collection(collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->clear_collection: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cluster_status**
> SearchFunctionNameBody cluster_status()

Get the status of all data-nodes

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))

try:
    # Get the status of all data-nodes
    api_response = api_instance.cluster_status()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->cluster_status: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**SearchFunctionNameBody**](SearchFunctionNameBody.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **commit**
> StatusDto commit(collection_name)

Commit

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 

try:
    # Commit
    api_response = api_instance.commit(collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->commit: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **create_collection**
> InlineResponse200 create_collection(file, collection_name)

Create a new collection

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
file = 'file_example' # str | 
collection_name = 'collection_name_example' # str | 

try:
    # Create a new collection
    api_response = api_instance.create_collection(file, collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->create_collection: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file** | **str**|  | 
 **collection_name** | **str**|  | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_collection**
> StatusDto delete_collection(collection_name)

Delete a collection

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 

try:
    # Delete a collection
    api_response = api_instance.delete_collection(collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->delete_collection: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_function**
> StatusDto delete_function(collection_name, function_name)

Delete function by name

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 
function_name = 'function_name_example' # str | 

try:
    # Delete function by name
    api_response = api_instance.delete_function(collection_name, function_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->delete_function: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 
 **function_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete_vector**
> StatusDto delete_vector(collection_name, vector_id)

Delete vector by Id 

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 
vector_id = 'vector_id_example' # str | 

try:
    # Delete vector by Id 
    api_response = api_instance.delete_vector(collection_name, vector_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->delete_vector: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 
 **vector_id** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **find_vector_by_id**
> InlineResponse200 find_vector_by_id(collection_name, vector_id)

Find vector by Id

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 
vector_id = 'vector_id_example' # str | 

try:
    # Find vector by Id
    api_response = api_instance.find_vector_by_id(collection_name, vector_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->find_vector_by_id: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 
 **vector_id** | **str**|  | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_function**
> SearchFunctionNameBody get_function(collection_name, function_name)

Get Function

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 
function_name = 'function_name_example' # str | 

try:
    # Get Function
    api_response = api_instance.get_function(collection_name, function_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->get_function: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 
 **function_name** | **str**|  | 

### Return type

[**SearchFunctionNameBody**](SearchFunctionNameBody.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_schema**
> SearchFunctionNameBody get_schema(collection_name)

Get schema of collection

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
collection_name = 'collection_name_example' # str | 

try:
    # Get schema of collection
    api_response = api_instance.get_schema(collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->get_schema: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **collection_name** | **str**|  | 

### Return type

[**SearchFunctionNameBody**](SearchFunctionNameBody.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **login**
> AuthDto login(body)

Login

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = search_master.SearchMasterApi()
body = search_master.LoginDto() # LoginDto | 

try:
    # Login
    api_response = api_instance.login(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->login: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LoginDto**](LoginDto.md)|  | 

### Return type

[**AuthDto**](AuthDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **search_data**
> SearchFunctionNameBody search_data(body, size, collection_name, function_name)

Find top X similar vectors in the dataset according to the selected search option.

Search Options: 1) Search for all similar vectors. 2) ................ 3) ............. 4) ...........

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
body = search_master.SearchFunctionNameBody() # SearchFunctionNameBody | 
size = 56 # int | 
collection_name = 'collection_name_example' # str | 
function_name = 'function_name_example' # str | 

try:
    # Find top X similar vectors in the dataset according to the selected search option.
    api_response = api_instance.search_data(body, size, collection_name, function_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->search_data: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SearchFunctionNameBody**](SearchFunctionNameBody.md)|  | 
 **size** | **int**|  | 
 **collection_name** | **str**|  | 
 **function_name** | **str**|  | 

### Return type

[**SearchFunctionNameBody**](SearchFunctionNameBody.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_function**
> StatusDto set_function(file, collection_name, function_name)

Set Function

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
file = 'file_example' # str | 
collection_name = 'collection_name_example' # str | 
function_name = 'function_name_example' # str | 

try:
    # Set Function
    api_response = api_instance.set_function(file, collection_name, function_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->set_function: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file** | **str**|  | 
 **collection_name** | **str**|  | 
 **function_name** | **str**|  | 

### Return type

[**StatusDto**](StatusDto.md)

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **update_vector**
> str update_vector(body, collection_name)

Update vector by Id in the dataset

### Example
```python
from __future__ import print_function
import time
import search_master
from search_master.rest import ApiException
from pprint import pprint


# create an instance of the API class
api_instance = search_master.SearchMasterApi(search_master.ApiClient(configuration))
body = search_master.VectorDto() # VectorDto | 
collection_name = 'collection_name_example' # str | 

try:
    # Update vector by Id in the dataset
    api_response = api_instance.update_vector(body, collection_name)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling SearchMasterApi->update_vector: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**VectorDto**](VectorDto.md)|  | 
 **collection_name** | **str**|  | 

### Return type

**str**

### Authorization

[bearer](../README.md#bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: text/plain

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

