# SearchResultsDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**similarity** | **list[dict(str, object)]** |  | [optional] 
**took_ms** | **float** |  | [optional] 
**candidates** | **int** |  | [optional] 
**cycles** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

